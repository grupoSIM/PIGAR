---
name: PIGAR Utility Core
colors:
  surface: '#f4faff'
  surface-dim: '#cfdce4'
  surface-bright: '#f4faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e9f6fd'
  surface-container: '#e3f0f8'
  surface-container-high: '#ddeaf2'
  surface-container-highest: '#d7e4ec'
  on-surface: '#111d23'
  on-surface-variant: '#414751'
  inverse-surface: '#263238'
  inverse-on-surface: '#e6f3fb'
  outline: '#727782'
  outline-variant: '#c1c7d2'
  surface-tint: '#1860a4'
  primary: '#003f74'
  on-primary: '#ffffff'
  primary-container: '#01579b'
  on-primary-container: '#abcdff'
  inverse-primary: '#a3c9ff'
  secondary: '#795900'
  on-secondary: '#ffffff'
  secondary-container: '#fec330'
  on-secondary-container: '#6f5100'
  tertiary: '#00490f'
  on-tertiary: '#ffffff'
  tertiary-container: '#006418'
  on-tertiary-container: '#87df82'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a3c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004882'
  secondary-fixed: '#ffdfa0'
  secondary-fixed-dim: '#f8bd2a'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#9df898'
  tertiary-fixed-dim: '#82db7e'
  on-tertiary-fixed: '#002204'
  on-tertiary-fixed-variant: '#005312'
  background: '#f4faff'
  on-background: '#111d23'
  surface-variant: '#d7e4ec'
  surface-client: '#E1F5FE'
  surface-operator: '#E8F5E9'
  surface-admin: '#FFF3E0'
  admin-orange: '#E65100'
  error-red: '#D32F2F'
  bg-gray: '#F5F7F8'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
  operator-action:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  touch-target-min: 48px
  thumb-zone-padding: 24px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 64px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is built on a foundation of **Utility-Driven Reliability**. It is designed for a home maintenance and repair ecosystem where clarity and efficiency are paramount, particularly in high-stress or outdoor environments. The brand personality is professional, stable, and highly functional, positioning itself as a dependable tool rather than a decorative lifestyle app.

The design style is **Corporate / Modern** with a strong emphasis on **High-Contrast** accessibility. It utilizes a structured, "Mobile-First" approach that prioritizes large, "thumb-friendly" hit areas to accommodate users who may be multitasking, in bright sunlight, or wearing work gloves. The visual language is clean and systematic, using color-coding to provide immediate cognitive shortcuts for different user roles and system states.

## Colors

The palette is role-based and semantic, ensuring that users can immediately identify their context within the PIGAR ecosystem.

*   **Primary (Navy Blue):** Used for trust, stability, and Client-side branding. It is the core color for headers and primary navigation.
*   **Secondary (Accent Yellow):** Reserved for critical Calls to Action (CTAs), decision-making nodes, and warnings. Its high visibility ensures key actions are never missed.
*   **Tertiary (Success Green):** Represents the Operator's domain and successful "Immediate Resolution" states.
*   **Neutral (Slate Gray):** Provides a grounded base for text and borders, ensuring high legibility against white and light-gray backgrounds.

**Color Modes & Accessibility:**
The default mode is `light`. High contrast is maintained across all surfaces to ensure visibility in outdoor environments. Role-specific surfaces (Client, Operator, Admin) use very light tints of their respective brand colors to provide a subtle, persistent background context.

## Typography

The typography system prioritizes legibility and a systematic hierarchy. **Hanken Grotesk** is used for headlines and high-impact labels to provide a clean, modern, and sharp appearance. **Inter** is utilized for body text and functional labels due to its exceptional readability on small screens.

*   **Operator-Specific Sizing:** For the mobile interface, the `operator-action` level is used for buttons to ensure labels remain legible even when the device is at arm's length or in bright light.
*   **Scalability:** Headlines transition to mobile-specific sizes to prevent layout overflow while maintaining a strong visual anchor at the top of pages.

## Layout & Spacing

This design system follows a **Mobile-First Fluid Grid** model.

**Mobile Strategy:**
The layout is optimized for the "Thumb Zone"—the lower 40% of the screen where critical actions like "Pay Now," "Record Diagnostic," or "Arrive at Site" are located. All primary interactive elements must meet a minimum 48px hit area.

**Grid System:**
- **Mobile:** 4-column fluid grid with 20px margins and 16px gutters.
- **Desktop (Admin Dashboard):** 12-column fixed grid (max-width 1440px) with 64px margins. The dashboard uses a modular multi-column view to allow for simultaneous map viewing and KPI monitoring.

**Spacing Rhythm:**
A base-8 increment system is used for internal component spacing (`stack-sm`, `stack-md`, `stack-lg`) to maintain a rigorous and predictable vertical rhythm.

## Elevation & Depth

To maintain high visibility in sunlight, the design system avoids complex shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**.

1.  **Tonal Layers:** Depth is communicated by stacking surfaces. The base background uses a neutral off-white or role-tinted surface, while interactive cards and modals sit on a pure white `#FFFFFF` surface.
2.  **Structural Borders:** Instead of deep shadows, 1px or 2px solid borders are used to define component boundaries, ensuring the UI remains crisp and high-contrast.
3.  **Overlays:** High-priority tasks (like Video Uploads or Maps) use a semi-transparent dark backdrop (`rgba(0,0,0,0.5)`) to focus the user's attention on the modal layer.
4.  **Admin Cards:** On the dashboard, cards use a subtle 4px blur, low-opacity shadow to provide enough lift to separate data modules without cluttering the interface.

## Shapes

The shape language is **Rounded**, striking a balance between professional precision and approachable utility.

*   **Standard Components:** Buttons, input fields, and cards use a 0.5rem (8px) radius. This provides a modern feel while maintaining a sense of structural integrity.
*   **Decision Diamonds:** In flow-based interfaces (like diagnostic trees), decision points use sharp or strictly geometric forms to distinguish them from standard action buttons.
*   **Role Identification:** Actor containers (Client vs. Operator) are consistently housed in rounded rectangles to signify they are interactive, distinct modules.

## Components

**Buttons:**
- **Primary:** Navy Blue background with white text. Used for "Submit" or "Accept."
- **Action (Yellow):** Accent Yellow background with Navy text. Used for "Thumb Zone" CTAs like "Pay" or "Emergency Repair."
- **Glove-Ready:** Extra padding (16px vertical) on mobile to ensure operators can tap easily.

**Input Fields:**
- Large text inputs with clear 1px borders. Focused states use a 2px Primary Blue border.
- **Multimedia Inputs:** Specific components for "Record 30s Video" and "Photo Upload" with large, centered icons and progress bars for background uploads.

**Chips & Status:**
- Use the semantic color-coding: Green for "Completed," Orange for "Pending Budget," and Red for "Cancelled."
- Status indicators must include an icon alongside the label for colorblind accessibility.

**Cards:**
- Used as the primary container for Service Requests.
- Each card should have a clear header, a summary of the issue, and a prominent role-based action button.

**Interactive Maps:**
- Full-width or large-modal components with distinct pins for Operator location and Client destination. Pins should use the Brand Blue for the target and Green for the operator.