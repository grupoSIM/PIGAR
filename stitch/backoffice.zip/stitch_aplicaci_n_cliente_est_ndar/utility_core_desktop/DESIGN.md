---
name: Utility Core Desktop
colors:
  surface: '#f8f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#414751'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727782'
  outline-variant: '#c1c7d2'
  surface-tint: '#1860a4'
  primary: '#003f74'
  on-primary: '#ffffff'
  primary-container: '#01579b'
  on-primary-container: '#abcdff'
  inverse-primary: '#a3c9ff'
  secondary: '#00639a'
  on-secondary: '#ffffff'
  secondary-container: '#51b2fe'
  on-secondary-container: '#00436a'
  tertiary: '#2d424b'
  on-tertiary: '#ffffff'
  tertiary-container: '#445963'
  on-tertiary-container: '#b9cfdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a3c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004882'
  secondary-fixed: '#cee5ff'
  secondary-fixed-dim: '#96ccff'
  on-secondary-fixed: '#001d32'
  on-secondary-fixed-variant: '#004a75'
  tertiary-fixed: '#cfe6f2'
  tertiary-fixed-dim: '#b4cad6'
  on-tertiary-fixed: '#071e27'
  on-tertiary-fixed-variant: '#354a53'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-width: 260px
  sidebar-collapsed: 72px
  container-max: 1600px
  gutter: 24px
  margin-desktop: 32px
  density-compact: 8px
  density-comfortable: 16px
---

## Brand & Style
The design system focuses on high-utility, data-dense environments for backoffice operations. It transitions from the mobile-first approach to a professional, **Corporate / Modern** desktop experience. The brand personality is efficient, authoritative, and stable, prioritizing cognitive clarity over decorative elements. It uses a structured layout to manage complex utility workflows, ensuring that administrators feel in control of large datasets. The aesthetic is clean and systematic, utilizing subtle tonal layering to organize information hierarchy without visual clutter.

## Colors
The palette is anchored by a professional Deep Ocean Blue (#01579B), signaling reliability and precision. 

- **Primary:** Used for key actions, active navigation states, and primary identifiers.
- **Secondary:** A lighter blue used for interactive highlights and informative accents.
- **Tertiary:** A cool slate grey for secondary metadata and less prominent interface elements.
- **Neutral:** A systematic range of cool greys. The background uses a very light tint (#F5F7F9) to reduce eye strain during long-form work sessions.
- **Semantic:** Success (Green), Warning (Amber), and Error (Red) are used sparingly to highlight system status and data anomalies.

## Typography
Hanken Grotesk is the sole typeface, chosen for its high legibility in dense data environments.
- **Headlines:** Bold and clear, used for page titles and section headers.
- **Body:** The default is `body-md` (14px) for dashboard content to maximize information density without sacrificing readability.
- **Labels:** Used for table headers, form labels, and small metadata. Table headers should use `label-md` in all-caps with the specified letter spacing.
- **Monospace:** `JetBrains Mono` is used strictly for technical data points like Meter IDs, IP addresses, or UUIDs.

## Layout & Spacing
The layout uses a **Fixed Sidebar + Fluid Content** model. 
- **Navigation:** A permanent Sidebar (Drawer) on the left. It can be collapsed to a Navigation Rail to increase canvas space for large tables.
- **Grid:** A 12-column fluid grid system within the main content area.
- **Density:** This design system utilizes a high-density rhythm. Spacing between related items in a data table is 8px (`density-compact`), while spacing between major dashboard cards is 24px (`gutter`).
- **Breakpoints:** 
  - Desktop: 1440px+ (Full sidebar)
  - Laptop: 1024px - 1439px (Collapsible sidebar)
  - Tablet: Below 1024px (Drawer becomes overlay)

## Elevation & Depth
In a backoffice context, depth is used to separate the workspace from the navigation and to highlight actionable overlays.
- **Level 0 (Background):** Neutral surface (#F5F7F9).
- **Level 1 (Cards/Sidebar):** Pure white (#FFFFFF) with a 1px border (#E0E4E8). No shadows are used for standard containers to keep the UI "flat" and fast.
- **Level 2 (Dropdowns/Popovers):** White surface with a soft ambient shadow (0px 4px 12px rgba(0, 0, 0, 0.08)).
- **Level 3 (Modals):** Centered overlays with a 20% opacity black backdrop and a more pronounced shadow to focus attention.

## Shapes
This design system uses **Soft (Level 1)** roundedness to maintain a professional, systematic appearance.
- **Buttons & Inputs:** 0.25rem (4px) radius. This creates a precise, architectural feel suitable for utility software.
- **Cards & Modals:** 0.5rem (8px) radius to provide a slight visual distinction from smaller components.
- **Data Tables:** Outer corners of the table container use 4px, while internal cells remain sharp.

## Components
- **Data Tables:** The core of the desktop experience. Headers use `label-md` with a subtle grey background. Rows have a fixed height of 48px (standard) or 40px (compact). Hover states use a light blue tint.
- **Sidebar:** Primary background is White or Deep Ocean Blue. Active items use a high-contrast indicator on the left edge. Icons are 20px, stroke-based.
- **Buttons:**
  - *Primary:* Solid #01579B with white text.
  - *Secondary:* Outlined with #01579B.
  - *Ghost:* Text only, used for table actions to reduce visual noise.
- **Filter Bar:** Horizontal bar above tables. Uses "Filter Chips" to show active parameters and "Input Groups" for quick searching.
- **Input Fields:** Rectangular with 1px borders. Focused state uses a 2px Primary Blue border.
- **Status Badges:** Small, pill-shaped indicators for "Active," "Pending," or "Error" using semantic colors with a 10% opacity background of the same hue.
- **Dashboard Cards:** Simple white containers with a 1px border. Title on the top left, actions (like "View All") on the top right.